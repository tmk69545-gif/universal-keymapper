ui_print "*************************************************"
ui_print "   Essential KeyMapper for Nothing & AOSP        "
ui_print "*************************************************"

# Check device architecture
ARCH=$(getprop ro.product.cpu.abi)
ui_print "- Device Architecture: $ARCH"
if [ "$ARCH" != "arm64-v8a" ] && [ "$ARCH" != "aarch64" ]; then
    ui_print "! Unsupported architecture: $ARCH (Requires aarch64)"
    abort "! Installation aborted"
fi

# Detect device model
MODEL=$(getprop ro.product.model)
DEVICE=$(getprop ro.product.device)
ui_print "- Detected Device: $MODEL ($DEVICE)"

# Preserve or create config file
CONFIG_TARGET="/data/adb/modules/essential_keymapper/keymapper.conf"
if [ -f "$CONFIG_TARGET" ]; then
    ui_print "- Existing user configuration preserved."
    cp -f "$CONFIG_TARGET" "$MODPATH/keymapper.conf"
elif [ -f "$MODPATH/keymapper.conf" ]; then
    ui_print "- Installing default configuration profile..."
fi

# Setup permissions
ui_print "- Setting binary and script permissions..."
set_perm "$MODPATH/system/bin/keyactiond" 0 0 0755
set_perm "$MODPATH/system/bin/keymapper" 0 0 0755
set_perm "$MODPATH/service.sh" 0 0 0755
set_perm "$MODPATH/uninstall.sh" 0 0 0755

if [ -d "$MODPATH/system/usr/keylayout" ]; then
    set_perm_recursive "$MODPATH/system/usr/keylayout" 0 0 0755 0644
fi

if [ -d "$MODPATH/vendor/usr/keylayout" ]; then
    set_perm_recursive "$MODPATH/vendor/usr/keylayout" 0 0 0755 0644
fi

ui_print " "
ui_print "*************************************************"
ui_print " Installation successful!"
ui_print " "
ui_print " Quick Controls:"
ui_print " - Essential Key: 1x=Flashlight, 2x=Screenshot, Hold=Camera"
ui_print " - Screen-off Vol+/Vol-: Hold to Skip/Prev Track"
ui_print " - Vol+ & Vol-: Press together for Screenshot"
ui_print " "
ui_print " Terminal Commands (Termux/Root Shell):"
ui_print "   su -c keymapper status"
ui_print "   su -c keymapper test"
ui_print "   su -c keymapper reload"
ui_print "*************************************************"
