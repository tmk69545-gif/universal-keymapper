#!/system/bin/sh
# Essential KeyMapper Background Service
MODDIR=${0%/*}

# Wait for Android boot completion
while [ "$(getprop sys.boot_completed)" != "1" ]; do
    sleep 2
done

# Extra settling delay
sleep 1

# Launch keyactiond daemon
DAEMON="/system/bin/keyactiond"
[ ! -x "$DAEMON" ] && DAEMON="$MODDIR/system/bin/keyactiond"

CONFIG="$MODDIR/keymapper.conf"
LOGFILE="$MODDIR/keyactiond.log"
PIDFILE="$MODDIR/keyactiond.pid"

if [ -x "$DAEMON" ]; then
    # Kill any stale instance
    pidof keyactiond 2>/dev/null | xargs kill -9 2>/dev/null

    nohup "$DAEMON" --config "$CONFIG" > "$LOGFILE" 2>&1 &
    PID=$!
    echo "$PID" > "$PIDFILE" 2>/dev/null
fi
